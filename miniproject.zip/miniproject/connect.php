<?php
$conn=mysqli_connect("localhost","root","","pawesome");
if(!$conn){
    echo "not connected";
}

?>