<?php ?>
<html>
    <head>
    <link rel="stylesheet"
href="servicesstyle.css">
</head>
    <body>
<div class="services">
    <div class="items">
        <div class="item first">
            <div class="content">
                <h1>Be a volunteer,<br>join our team</h1>
                <p>Join our team PaweSome and become our volunteer & help animals<br><br>
                Right time...right choice</p>
                <a href="sign_up.php"><b>REGISTER NOW</b></a>
            </div>
        </div>
        <div class="item second">
            <div class="content">
                <h1>Adopt your new companion</h1>
                <p>Adopt your new companion ,give wings to a new life <br>
                <br>
            Never late to start a change....</p>
                <a href="sign_up.php"><b>ADOPT NOW</b></a>
            </div>
        </div>
        <div class="item third">
            <div class="content">
                <h1>A pet sitter for every occasion</h1>
                <p>Local pet care services for your best friend.
                    <br>keeps your pets always  safe with us...</p>
                <a href="sign_up.php"><b>BOOK NOW</b></a>
            </div>
        </div>
    </div>

  </div>
</body>
  </html>