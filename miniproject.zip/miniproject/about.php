<?php ?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us Section</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<link rel="stylesheet" type="text/css" href="aboutstyle.css">
</head>	
<body>
	<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h1>About Us</h1>
				</div>
				<div class="content">
                <h3 >
        Join our initiative to speak for the voiceless...
        <br>PaweSome aims at rescuing the needed animals<br>
        not just words but a promise..<br>
        put our hands together for rewriting their future.. 
        
           
      
    
         </h3>
					<h3>PAWSOME : THE BEST PLACE FOR YOUR LITTILE LOVED ONES</h3>
					<p>Pawsome is an charitable petshop. we maily focus on rescuing the stray animals who are in desparate need of a home. Through this organisation you can either volunteer for oru pet rescue oprations or donate us<br>

                 Do you want to travel but can't coz there is no one take care of your littile ones??<br>
                 hey!!! We are more than happy to help you guys.Our pet-sitting services are one of the best and we love and take care of your pets as our own.<br><br>
       
                    </p>
					<div class="button">
						<a href="">Read More</a>
					</div>
				</div>
				<div class="social">
					<a href=""><i class="fab fa-facebook-f"></i></a>
					<a href=""><i class="fab fa-twitter"></i></a>
					<a href=""><i class="fab fa-instagram"></i></a>
				</div>
			</div>
			<div class="image-section">
				<img src="./about.jpg">
			</div>
		</div>
	</div>

	
</body>
</html>